/********************************************************************************
** Form generated from reading UI file 'errorwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ERRORWIDGET_H
#define UI_ERRORWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ErrorWidget
{
public:
    QToolButton *toolButton;

    void setupUi(QWidget *ErrorWidget)
    {
        if (ErrorWidget->objectName().isEmpty())
            ErrorWidget->setObjectName(QStringLiteral("ErrorWidget"));
        ErrorWidget->resize(408, 207);
        toolButton = new QToolButton(ErrorWidget);
        toolButton->setObjectName(QStringLiteral("toolButton"));
        toolButton->setGeometry(QRect(120, 120, 171, 41));

        retranslateUi(ErrorWidget);

        QMetaObject::connectSlotsByName(ErrorWidget);
    } // setupUi

    void retranslateUi(QWidget *ErrorWidget)
    {
        ErrorWidget->setWindowTitle(QApplication::translate("ErrorWidget", "Error", 0));
        toolButton->setText(QApplication::translate("ErrorWidget", "KEMBALI", 0));
    } // retranslateUi

};

namespace Ui {
    class ErrorWidget: public Ui_ErrorWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ERRORWIDGET_H
